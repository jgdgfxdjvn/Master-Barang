<div class="container mt-4">
    <div style= "background-image: url('resources/images/me.jpg')">
    </div>
    <h4>Go To "My Profile" To See Biodata. WELCOMING!</h4>
    <hr>
    <div class="d-flex align-items-center py-2 px-4 bg-light rounded-3border"></div>
</body>
</div>
